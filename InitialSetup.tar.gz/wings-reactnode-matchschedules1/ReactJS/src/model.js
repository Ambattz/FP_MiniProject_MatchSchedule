const model = [
  { key: 1, title: "Team One", column_name: "team1", input_type: "text" },
  { key: 2, title: "Team Two", column_name: "team2", input_type: "text" },
  { key: 3, title: "Venue", column_name: "venue", input_type: "text" },
  { key: 4, title: "Match Date", column_name: "date", input_type: "date" },
];

export default model;